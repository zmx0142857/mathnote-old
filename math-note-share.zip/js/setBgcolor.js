/**
 * Set beautiful background color for your webpage.
 * Created by cookie on 1/7/2017. Modified by Clarence later that day.
 */
var background = document.getElementsByTagName("body");
background[0].style.backgroundColor = randomColor({luminosity: "light"});
